package com.mangareader.manager

import android.content.Context
import java.io.File

/**
 * Utility for querying and clearing the app's disk caches.
 *
 * Cache layout under [Context.cacheDir]:
 *   manga/<seriesId>/<chapterId>/   decoded page images + .version stamp
 *   thumbs/<seriesId>.jpg           cover thumbnail
 */
class CacheManager(private val context: Context) {

    private val mangaRoot  get() = File(context.cacheDir, "manga")
    private val thumbsRoot get() = File(context.cacheDir, "thumbs")

    // ── Size queries ───────────────────────────────────────────────────────────

    /** Total bytes used by all decoded page image caches. */
    fun mangaCacheSizeBytes(): Long = mangaRoot.dirSizeBytes()

    /** Total bytes used by cover thumbnails. */
    fun thumbnailCacheSizeBytes(): Long = thumbsRoot.dirSizeBytes()

    /** Combined size of all caches managed by this class. */
    fun totalCacheSizeBytes(): Long = mangaCacheSizeBytes() + thumbnailCacheSizeBytes()

    // ── Clear operations ───────────────────────────────────────────────────────

    /** Deletes all decoded page images for every series. Thumbnails are kept. */
    fun clearPageCache() { mangaRoot.deleteRecursively() }

    /** Deletes all cover thumbnails. They will regenerate on next library open. */
    fun clearThumbnailCache() { thumbsRoot.deleteRecursively() }

    /** Deletes all caches managed by this class. */
    fun clearAll() { clearPageCache(); clearThumbnailCache() }

    /** Deletes the page image cache and thumbnail for a single series. */
    fun clearSeries(seriesId: String) {
        File(mangaRoot, seriesId).deleteRecursively()
        File(thumbsRoot, "$seriesId.jpg").delete()
    }

    /**
     * Deletes page image caches for series that no longer exist in the library.
     * Prevents orphaned cache directories from accumulating after series deletion.
     */
    fun pruneOrphans(liveSeriesIds: Set<String>) {
        mangaRoot.listFiles()?.forEach { dir ->
            if (dir.isDirectory && dir.name !in liveSeriesIds) {
                dir.deleteRecursively()
            }
        }
        thumbsRoot.listFiles()?.forEach { f ->
            val id = f.nameWithoutExtension
            if (id !in liveSeriesIds) f.delete()
        }
    }

    // ── Helpers ────────────────────────────────────────────────────────────────

    private fun File.dirSizeBytes(): Long {
        if (!exists()) return 0L
        return walkTopDown().filter { it.isFile }.sumOf { it.length() }
    }
}

/** Formats a byte count as a human-readable string (e.g. "42.3 MB"). */
fun Long.formatBytes(): String = when {
    this >= 1_073_741_824L -> "%.1f GB".format(this / 1_073_741_824.0)
    this >= 1_048_576L     -> "%.1f MB".format(this / 1_048_576.0)
    this >= 1_024L         -> "%.1f KB".format(this / 1_024.0)
    else                   -> "$this B"
}
