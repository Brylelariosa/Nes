package com.mangareader.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val ColorScheme = darkColorScheme(
    primary          = Color(0xFF9D7DDB),
    onPrimary        = Color(0xFF1A0A40),
    primaryContainer = Color(0xFF2C1A5C),
    onPrimaryContainer = Color(0xFFD8BBFF),
    secondary        = Color(0xFF6FCFCF),
    onSecondary      = Color(0xFF00303F),
    background       = Color(0xFF0D0D0D),
    onBackground     = Color(0xFFE8E8E8),
    surface          = Color(0xFF181818),
    onSurface        = Color(0xFFE8E8E8),
    surfaceVariant   = Color(0xFF252525),
    onSurfaceVariant = Color(0xFFAAAAAA),
    error            = Color(0xFFCF6679),
    outline          = Color(0xFF404040),
)

@Composable
fun MangaReaderTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = ColorScheme,
        content     = content
    )
}
