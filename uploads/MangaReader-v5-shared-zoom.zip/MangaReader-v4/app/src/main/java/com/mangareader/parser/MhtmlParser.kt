package com.mangareader.parser

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import com.mangareader.manager.SettingsManager.SortOrder
import java.io.BufferedReader
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.io.InputStreamReader

/**
 * Parses MHTML files and extracts embedded images to a cache directory.
 *
 * WHY ORDERING IS HARD
 * Browser MHTML saves image resources in load order, not reading order.
 * Sites like MangaFire preload pages in reverse (last page first) so the
 * visible pages appear instantly on scroll. This means encounter order in
 * the file gives pages backwards.
 *
 * URL hashes on these CDNs carry no sequential meaning, so URL-digit
 * extraction also fails.
 *
 * THE CORRECT APPROACH
 * The only ground truth is the HTML part of the MHTML itself: the browser
 * saves the fully rendered DOM, which lists <img> tags in reading order.
 * Sites like MangaFire also add an explicit data-number attribute (1, 2, 3…)
 * on each page image, which we prefer over positional inference.
 *
 * QUOTED-PRINTABLE DECODING
 * The text/html MIME part is typically Content-Transfer-Encoding: quoted-
 * printable. This means:
 *   - "=" is encoded as "=3D"
 *   - Long lines are split with a "=" at the end (soft line break)
 *
 * A naive regex on the raw bytes will NEVER find the img src URL because it
 * is split across two raw lines. We must:
 *   1. Join soft line breaks (strip trailing "=\n")
 *   2. Decode "=XX" byte sequences
 * …before running any regex against the HTML.
 *
 * ALGORITHM (single pass)
 *   1. Accumulate the first text/html MIME part into a buffer.
 *   2. On the part boundary, QP-decode the buffer, parse every <img> tag,
 *      and build a map:  decoded_src_url → sort_key
 *      where sort_key = data-number when present, else document position.
 *   3. For each subsequent image MIME part, look up its Content-Location
 *      in that map to get its reading-order position.
 *   4. Sort pending images by that position.
 *
 * This correctly handles MangaFire's reverse-order MHTML, and degrades
 * gracefully to URL-digit or encounter-order fallbacks on sites where the
 * HTML has no parseable img src attributes.
 */
class MhtmlParser(private val context: Context) {

    private val boundaryRegex = Regex(
        """boundary=["']?([^"'\r\n;]+)["']?""", RegexOption.IGNORE_CASE
    )
    private val nonImageContentTypeHints = listOf(
        "text/", "application/javascript", "application/x-javascript",
        "application/json", "font/", "application/font", "application/x-font"
    )

    // After QP-decode the HTML is normal HTML — these regexes expect plain quotes.
    private val imgTagRegex  = Regex("""<img\b[^>]+>""", RegexOption.IGNORE_CASE)
    private val srcAttrRegex = Regex(
        """(?:src|data-src|data-original|data-lazy(?:-src)?)\s*=\s*["']([^"'?#\s]+)""",
        RegexOption.IGNORE_CASE
    )
    private val dataNumberRegex = Regex(
        """data-number\s*=\s*["']?(\d+)""", RegexOption.IGNORE_CASE
    )

    // ── Public API ─────────────────────────────────────────────────────────────

    fun extractImages(
        mhtmlPath: String,
        cacheDir: File,
        minImageDimension: Int = 120,
        sortOrder: SortOrder = SortOrder.AUTO
    ): List<File> = try {
        openStream(mhtmlPath)?.use {
            extractImages(it, cacheDir, minImageDimension, sortOrder)
        } ?: emptyList()
    } catch (e: Exception) { e.printStackTrace(); emptyList() }

    fun extractImages(
        inputStream: InputStream,
        cacheDir: File,
        minImageDimension: Int = 120,
        sortOrder: SortOrder = SortOrder.AUTO
    ): List<File> {
        cacheDir.mkdirs()

        data class Pending(
            val file: File,
            val htmlPos: Int?,  // reading-order position from HTML (may be data-number)
            val pageNum: Int?,  // digit extracted from Content-Location URL
            val order: Int      // encounter order in MHTML file
        )
        val pending  = mutableListOf<Pending>()
        var encounterIndex = 0

        // URL → reading-order sort key, populated from the HTML part.
        val htmlOrder = mutableMapOf<String, Int>()

        try {
            val reader = BufferedReader(
                InputStreamReader(inputStream, Charsets.ISO_8859_1), 64 * 1024
            )
            val boundary = findBoundary(reader) ?: return emptyList()
            val delimiter = "--$boundary"

            val headerBuilder   = StringBuilder()
            val bodyBuilder     = StringBuilder()
            val htmlBodyBuilder = StringBuilder()
            var inBody              = false
            var isImagePart         = false
            var isHtmlPart          = false
            var contentLocationUrl  = ""
            var pageNum: Int?       = null
            var htmlPartsProcessed  = 0
            var totalParts          = 0

            // Called when a MIME boundary closes the HTML part.
            // Decodes QP and populates htmlOrder.
            fun finaliseHtmlPart() {
                if (!isHtmlPart || htmlBodyBuilder.isEmpty()) return
                val decoded = decodeQP(htmlBodyBuilder.toString())
                var positionCounter = 0
                imgTagRegex.findAll(decoded).forEach { m ->
                    val tag = m.value
                    val src = srcAttrRegex.find(tag)?.groupValues?.get(1)
                        ?.trim() ?: return@forEach
                    if (src.isBlank() || src.startsWith("data:")) return@forEach

                    // data-number is the authoritative page index on sites like MangaFire.
                    // Fall back to document position on sites that don't use it.
                    val sortKey = dataNumberRegex.find(tag)
                        ?.groupValues?.get(1)?.toIntOrNull() ?: positionCounter

                    htmlOrder.putIfAbsent(src, sortKey)

                    // Filename-only key for sites where HTML uses relative URLs
                    // but Content-Location is absolute (only useful when filenames
                    // are unique — putIfAbsent skips duplicates like "p.jpg").
                    val fname = src.substringAfterLast('/').substringBefore('?')
                    if (fname.isNotBlank()) htmlOrder.putIfAbsent(fname, sortKey)

                    positionCounter++
                }
                htmlBodyBuilder.setLength(0)
                htmlPartsProcessed++
            }

            fun flush() {
                if (!isImagePart || bodyBuilder.isEmpty()) return
                try {
                    val bytes = Base64.decode(bodyBuilder.toString(), Base64.DEFAULT)
                    val ext   = sniffImageExt(bytes) ?: return
                    if (bytes.size <= 200) return

                    if (minImageDimension > 0) {
                        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts)
                        if (opts.outWidth  < minImageDimension ||
                            opts.outHeight < minImageDimension) return
                    }

                    val htmlPos = lookupHtmlPos(contentLocationUrl, htmlOrder)
                    val tmp = File(cacheDir, "tmp_$encounterIndex.$ext")
                    tmp.writeBytes(bytes)
                    pending.add(Pending(tmp, htmlPos, pageNum, encounterIndex))
                    encounterIndex++
                } catch (_: Exception) { }
            }

            fun reset() {
                headerBuilder.setLength(0); bodyBuilder.setLength(0)
                inBody = false; isImagePart = false; isHtmlPart = false
                contentLocationUrl = ""; pageNum = null
            }

            var line: String?
            while (true) {
                line = reader.readLine() ?: break
                val l = line!!

                if (l.startsWith(delimiter)) {
                    finaliseHtmlPart()
                    flush()
                    reset()
                    totalParts++
                    if (l.startsWith("$delimiter--")) break
                    continue
                }

                if (!inBody) {
                    if (l.isEmpty()) {
                        inBody = true
                        val headersStr = headerBuilder.toString()

                        // Only scan first 10 MIME parts for the HTML part.
                        isHtmlPart = htmlPartsProcessed == 0 &&
                            totalParts < 10 &&
                            headersStr.contains("text/html", ignoreCase = true)

                        isImagePart = !isHtmlPart && isLikelyImagePart(headerBuilder)

                        contentLocationUrl = headerBuilder.lineSequence()
                            .firstOrNull { it.contains("content-location", ignoreCase = true) }
                            ?.substringAfter(':')?.trim().orEmpty()

                        if (isImagePart) pageNum = extractPageNumber(contentLocationUrl)
                    } else {
                        headerBuilder.append(l).append('\n')
                    }
                } else {
                    when {
                        isHtmlPart && htmlBodyBuilder.length < 2_000_000 ->
                            // Append raw QP lines — decodeQP handles joining later.
                            htmlBodyBuilder.append(l).append('\n')
                        isImagePart ->
                            bodyBuilder.append(l)
                    }
                }
            }
            finaliseHtmlPart()
            flush()

        } catch (e: Exception) { e.printStackTrace() }

        if (pending.isEmpty()) return emptyList()

        val ordered: List<Pending> = when (sortOrder) {

            SortOrder.ENCOUNTER -> pending.sortedBy { it.order }

            SortOrder.URL_PAGE -> pending.sortedWith(
                compareBy({ it.pageNum == null }, { it.pageNum ?: Int.MAX_VALUE }, { it.order })
            )

            SortOrder.AUTO -> {
                val hasHtmlPositions = pending.any { it.htmlPos != null }

                if (hasHtmlPositions) {
                    // Primary: reading order from HTML document structure.
                    // Images not matched (no src in HTML map) are appended at end.
                    pending.sortedWith(
                        compareBy(
                            { it.htmlPos == null },
                            { it.htmlPos ?: Int.MAX_VALUE },
                            { it.order }
                        )
                    )
                } else {
                    // No HTML positions: try URL page-number heuristic.
                    val numbered = pending.filter { it.pageNum != null }
                        .sortedBy { it.pageNum }
                    val reliable = numbered.size >= 2 &&
                        numbered.size >= pending.size / 2 &&
                        numbered.zipWithNext().all { (a, b) ->
                            (b.pageNum!! - a.pageNum!!) <= 10
                        }
                    if (reliable)
                        pending.sortedWith(
                            compareBy(
                                { it.pageNum == null },
                                { it.pageNum ?: Int.MAX_VALUE },
                                { it.order }
                            )
                        )
                    else
                        pending.sortedBy { it.order }
                }
            }
        }

        return ordered.mapIndexedNotNull { i, p ->
            val target = File(
                cacheDir,
                "page_${(i + 1).toString().padStart(4, '0')}.${p.file.extension}"
            )
            if (p.file.renameTo(target)) target else null
        }
    }

    // ── Thumbnail ──────────────────────────────────────────────────────────────

    fun extractFirstPageThumbnail(
        mhtmlPath: String,
        outFile: File,
        maxDimension: Int = 480
    ): Boolean {
        val bytes = try {
            openStream(mhtmlPath)?.use { extractFirstPageBytes(it) }
        } catch (e: Exception) { e.printStackTrace(); null } ?: return false

        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return false
            var sample = 1
            while (bounds.outWidth  / (sample * 2) >= maxDimension ||
                   bounds.outHeight / (sample * 2) >= maxDimension) sample *= 2
            val bitmap = BitmapFactory.decodeByteArray(
                bytes, 0, bytes.size,
                BitmapFactory.Options().apply { inSampleSize = sample }
            ) ?: return false
            outFile.parentFile?.mkdirs()
            FileOutputStream(outFile).use { bitmap.compress(Bitmap.CompressFormat.JPEG, 82, it) }
            bitmap.recycle(); true
        } catch (e: Exception) { e.printStackTrace(); false }
    }

    private fun extractFirstPageBytes(inputStream: InputStream): ByteArray? {
        val reader = BufferedReader(
            InputStreamReader(inputStream, Charsets.ISO_8859_1), 64 * 1024
        )
        val boundary  = findBoundary(reader) ?: return null
        val delimiter = "--$boundary"
        val hdr = StringBuilder(); val body = StringBuilder()
        var inBody = false; var isImg = false

        fun tryDecode(): ByteArray? {
            if (!isImg || body.isEmpty()) return null
            return try {
                val b = Base64.decode(body.toString(), Base64.DEFAULT)
                if (b.size > 200 && sniffImageExt(b) != null) b else null
            } catch (_: Exception) { null }
        }

        var line: String?
        while (true) {
            line = reader.readLine() ?: break
            val l = line!!
            if (l.startsWith(delimiter)) {
                tryDecode()?.let { return it }
                hdr.setLength(0); body.setLength(0)
                inBody = false; isImg = false
                if (l.startsWith("$delimiter--")) return null
                continue
            }
            if (!inBody) {
                if (l.isEmpty()) { inBody = true; isImg = isLikelyImagePart(hdr) }
                else hdr.append(l).append('\n')
            } else if (isImg) body.append(l)
        }
        return tryDecode()
    }

    // ── Helpers ────────────────────────────────────────────────────────────────

    private fun openStream(path: String): InputStream? =
        if (path.startsWith("content://"))
            context.contentResolver.openInputStream(Uri.parse(path))
        else File(path).inputStream()

    private fun findBoundary(reader: BufferedReader): String? {
        val peek = StringBuilder(); var line: String?
        while (true) {
            line = reader.readLine() ?: break
            peek.append(line).append('\n')
            boundaryRegex.find(peek)?.let { return it.groupValues[1].trim() }
            if (peek.length > 8192) break
        }
        return null
    }

    private fun isLikelyImagePart(headers: CharSequence): Boolean {
        val ct = headers.lineSequence()
            .firstOrNull { it.contains("content-type", ignoreCase = true) }
            ?.lowercase() ?: return true
        return nonImageContentTypeHints.none { ct.contains(it) }
    }

    /**
     * Decodes a quoted-printable string:
     *   1. Removes soft line breaks (= at end of line).
     *   2. Decodes =XX byte sequences.
     *
     * Must be done before any regex parsing of the HTML body, because img src
     * URLs are split across lines by QP soft breaks and `=` is encoded as `=3D`
     * inside HTML attributes.
     */
    private fun decodeQP(encoded: String): String {
        // Step 1: join soft line breaks (= immediately before \r?\n)
        val joined = encoded.replace(Regex("""=\r?\n"""), "")
        // Step 2: decode =XX hex sequences
        return joined.replace(Regex("""=([0-9A-Fa-f]{2})""")) { m ->
            m.groupValues[1].toInt(16).toChar().toString()
        }
    }

    /**
     * Looks up reading-order position for an image by its Content-Location.
     * Tries the full URL first, then bare filename as fallback.
     */
    private fun lookupHtmlPos(contentLocation: String, order: Map<String, Int>): Int? {
        if (order.isEmpty() || contentLocation.isBlank()) return null
        order[contentLocation]?.let { return it }
        val fname = contentLocation.substringAfterLast('/')
            .substringBefore('?').substringBefore('#')
        return order[fname]
    }

    /**
     * Extracts a page number from a Content-Location URL.
     * Priority: "page"/"pg" keyword → zero-padded number → bare number ≤ 2000.
     */
    private fun extractPageNumber(rawUrl: String): Int? {
        if (rawUrl.isBlank()) return null
        val fname = rawUrl.substringBefore('?').substringBefore('#').substringAfterLast('/')
        Regex("""(?:page|pg)[_\-]?0*(\d+)""", RegexOption.IGNORE_CASE)
            .find(fname)?.groupValues?.get(1)?.toIntOrNull()?.let { return it }
        Regex("""_0*(\d{1,4})\.\w{2,5}$""")
            .find(fname)?.groupValues?.get(1)?.toIntOrNull()?.let { return it }
        val raw = Regex("""(\d+)\.\w{2,5}$""")
            .find(fname)?.groupValues?.get(1)?.toIntOrNull() ?: return null
        return if (raw <= 2000) raw else null
    }

    private fun sniffImageExt(bytes: ByteArray): String? {
        if (bytes.size < 12) return null
        return when {
            bytes[0] == 0xFF.toByte() && bytes[1] == 0xD8.toByte() -> "jpg"
            bytes[0] == 0x89.toByte() && bytes[1] == 0x50.toByte() &&
            bytes[2] == 0x4E.toByte() && bytes[3] == 0x47.toByte() -> "png"
            bytes[0] == 0x47.toByte() && bytes[1] == 0x49.toByte() &&
            bytes[2] == 0x46.toByte()                               -> "gif"
            bytes[0] == 0x52.toByte() && bytes[1] == 0x49.toByte() &&
            bytes[2] == 0x46.toByte() && bytes[3] == 0x46.toByte() &&
            bytes[8] == 0x57.toByte() && bytes[9] == 0x45.toByte() &&
            bytes[10] == 0x42.toByte()&& bytes[11] == 0x50.toByte() -> "webp"
            bytes[0] == 0x42.toByte() && bytes[1] == 0x4D.toByte() -> "bmp"
            else -> null
        }
    }
}
