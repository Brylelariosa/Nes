package com.mangareader.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mangareader.data.Chapter
import com.mangareader.data.ReadingProgress
import com.mangareader.data.ReadingMode
import com.mangareader.manager.ProgressManager
import com.mangareader.manager.SettingsManager
import com.mangareader.manager.SettingsManager.SortOrder
import com.mangareader.parser.MhtmlParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class ReaderViewModel(app: Application) : AndroidViewModel(app) {

    private val mhtmlParser     = MhtmlParser(app)
    private val progressManager = ProgressManager(app)
    private val settingsManager = SettingsManager(app)

    // ── Page state ─────────────────────────────────────────────────────────────

    private val _pages   = MutableStateFlow<List<File>>(emptyList())
    val pages: StateFlow<List<File>> = _pages

    private val _loading = MutableStateFlow(false)
    val loading: StateFlow<Boolean> = _loading

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    // ── Settings exposed to UI ─────────────────────────────────────────────────

    private val _scrollSpeed       = MutableStateFlow(settingsManager.scrollSpeed)
    val scrollSpeed: StateFlow<Float> = _scrollSpeed

    private val _minImageDimension = MutableStateFlow(settingsManager.minImageDimension)
    val minImageDimension: StateFlow<Int> = _minImageDimension

    private val _sortOrder         = MutableStateFlow(settingsManager.sortOrder)
    val sortOrder: StateFlow<SortOrder> = _sortOrder

    private val _readingMode       = MutableStateFlow(settingsManager.readingMode)
    val readingMode: StateFlow<ReadingMode> = _readingMode

    private val _keepScreenAwake   = MutableStateFlow(settingsManager.keepScreenAwake)
    val keepScreenAwake: StateFlow<Boolean> = _keepScreenAwake

    private val _autoMarkRead      = MutableStateFlow(settingsManager.autoMarkRead)
    val autoMarkRead: StateFlow<Boolean> = _autoMarkRead

    private val _preloadNext       = MutableStateFlow(settingsManager.preloadNextChapter)
    val preloadNext: StateFlow<Boolean> = _preloadNext

    // ── Chapter state ──────────────────────────────────────────────────────────

    private var currentChapter: Chapter? = null
    private var currentSeriesId   = ""
    private var currentChapterIdx = 0
    private var allChapters: List<Chapter> = emptyList()

    /**
     * Tracks the active extraction coroutine so we can cancel it if the user
     * navigates to a different chapter before it finishes — preventing the
     * previous chapter's pages from overwriting the new chapter's state.
     */
    private var loadingJob: Job? = null

    /** Separate job for preloading the next chapter; cancelled independently. */
    private var preloadJob: Job? = null

    // ── Chapter loading ────────────────────────────────────────────────────────

    /**
     * Loads [chapter] at position [chapterIndex] in [chapters].
     * Cancels any in-progress extraction before starting the new one, so
     * rapidly tapping "next chapter" never causes the wrong pages to appear.
     */
    fun loadChapter(
        chapter: Chapter,
        chapterIndex: Int,
        chapters: List<Chapter> = allChapters
    ) {
        // Cancel previous extraction immediately
        loadingJob?.cancel()
        preloadJob?.cancel()

        currentChapter    = chapter
        currentSeriesId   = chapter.seriesId
        currentChapterIdx = chapterIndex
        allChapters       = chapters

        loadingJob = viewModelScope.launch {
            _loading.value = true
            _error.value   = null
            _pages.value   = emptyList()

            val seriesCacheRoot = File(
                getApplication<Application>().cacheDir, "manga/${chapter.seriesId}"
            )
            val cacheDir    = File(seriesCacheRoot, chapter.id)
            val versionFile = File(cacheDir, ".version")

            runCatching {
                withContext(Dispatchers.IO) {
                    val cachedVersion = runCatching {
                        versionFile.readText().trim().toInt()
                    }.getOrDefault(-1)

                    val cached = if (cacheDir.exists() && cachedVersion == PARSER_VERSION) {
                        cacheDir.listFiles()
                            ?.filter { it.extension in IMAGE_EXTS }
                            ?.sortedBy { it.name }
                            .orEmpty()
                    } else emptyList()

                    if (cached.isNotEmpty()) {
                        cacheDir.setLastModified(System.currentTimeMillis())
                        cached
                    } else {
                        if (cacheDir.exists()) cacheDir.deleteRecursively()
                        cacheDir.mkdirs()

                        val extracted = mhtmlParser.extractImages(
                            mhtmlPath         = chapter.mhtmlPath,
                            cacheDir          = cacheDir,
                            minImageDimension = settingsManager.minImageDimension,
                            sortOrder         = settingsManager.sortOrder
                        )
                        if (extracted.isNotEmpty()) {
                            versionFile.writeText(PARSER_VERSION.toString())
                        }
                        pruneOldChapterCache(seriesCacheRoot, cacheDir)
                        extracted
                    }
                }
            }.onSuccess { files ->
                _pages.value = files
                if (files.isEmpty()) {
                    _error.value = "No images found in this chapter"
                } else {
                    // Kick off preload of the next chapter in the background.
                    maybePreloadNext(chapterIndex, chapters)
                }
            }.onFailure { e ->
                if (e is kotlinx.coroutines.CancellationException) return@onFailure
                _error.value = "Failed to load: ${e.message}"
            }

            _loading.value = false
        }
    }

    /**
     * Preloads the next chapter's images into the disk cache so they're
     * available instantly when the user reaches the end of the current chapter.
     * Runs at low priority and is cancelled if a real chapter load starts.
     */
    private fun maybePreloadNext(currentIdx: Int, chapters: List<Chapter>) {
        if (!settingsManager.preloadNextChapter) return
        val nextChapter = chapters.getOrNull(currentIdx + 1) ?: return

        preloadJob = viewModelScope.launch(Dispatchers.IO) {
            val seriesCacheRoot = File(
                getApplication<Application>().cacheDir, "manga/${nextChapter.seriesId}"
            )
            val cacheDir    = File(seriesCacheRoot, nextChapter.id)
            val versionFile = File(cacheDir, ".version")

            // Skip if already cached at the current version
            val cached = if (cacheDir.exists()) {
                val v = runCatching { versionFile.readText().trim().toInt() }.getOrDefault(-1)
                v == PARSER_VERSION && (cacheDir.listFiles()
                    ?.any { it.extension in IMAGE_EXTS } == true)
            } else false

            if (!cached) {
                runCatching {
                    if (cacheDir.exists()) cacheDir.deleteRecursively()
                    cacheDir.mkdirs()
                    val extracted = mhtmlParser.extractImages(
                        mhtmlPath         = nextChapter.mhtmlPath,
                        cacheDir          = cacheDir,
                        minImageDimension = settingsManager.minImageDimension,
                        sortOrder         = settingsManager.sortOrder
                    )
                    if (extracted.isNotEmpty()) {
                        versionFile.writeText(PARSER_VERSION.toString())
                    }
                }
            }
        }
    }

    private fun pruneOldChapterCache(
        seriesCacheRoot: File,
        keepDir: File,
        keep: Int = settingsManager.maxCachedChaptersPerSeries
    ) {
        val dirs = seriesCacheRoot.listFiles()?.filter { it.isDirectory } ?: return
        dirs.sortedByDescending { it.lastModified() }
            .drop(keep)
            .filter { it.absolutePath != keepDir.absolutePath }
            .forEach { it.deleteRecursively() }
    }

    // ── Progress ───────────────────────────────────────────────────────────────

    fun saveProgress(pageIndex: Int, scrollOffset: Int = 0) {
        if (currentSeriesId.isEmpty()) return
        progressManager.saveProgress(
            ReadingProgress(
                seriesId     = currentSeriesId,
                chapterIndex = currentChapterIdx,
                chapterId    = currentChapter?.id,
                pageIndex    = pageIndex,
                scrollOffset = scrollOffset
            )
        )
    }

    /**
     * Called when the reader reaches the last page of a chapter.
     * Marks the chapter as read if [autoMarkRead] is enabled, and saves
     * progress pointing at the last page.
     */
    fun onLastPageReached() {
        val ch = currentChapter ?: return
        saveProgress(
            pageIndex    = (_pages.value.size - 1).coerceAtLeast(0),
            scrollOffset = 0
        )
        if (settingsManager.autoMarkRead) {
            progressManager.markChapterRead(currentSeriesId, ch.id)
        }
    }

    // ── Resolve progress → chapter ─────────────────────────────────────────────

    /**
     * Given saved [progress], finds the index of the chapter to restore.
     * Prefers matching by chapter ID (stable across reorders/additions) and
     * falls back to the stored index when no ID is available or no match found.
     */
    fun resolveChapterIndex(progress: ReadingProgress, chapters: List<Chapter>): Int {
        // Try stable ID match first
        if (progress.chapterId != null) {
            val idx = chapters.indexOfFirst { it.id == progress.chapterId }
            if (idx >= 0) return idx
        }
        // Fall back to index (legacy data or no ID stored)
        return progress.chapterIndex.coerceIn(0, (chapters.size - 1).coerceAtLeast(0))
    }

    // ── Cache ──────────────────────────────────────────────────────────────────

    fun clearCache(chapter: Chapter) {
        File(
            getApplication<Application>().cacheDir,
            "manga/${chapter.seriesId}/${chapter.id}"
        ).deleteRecursively()
    }

    fun reloadChapter() {
        val ch = currentChapter ?: return
        clearCache(ch)
        loadChapter(ch, currentChapterIdx)
    }

    // ── Settings mutators ──────────────────────────────────────────────────────

    fun setScrollSpeed(v: Float) {
        settingsManager.scrollSpeed = v; _scrollSpeed.value = v
    }

    fun setMinImageDimension(v: Int) {
        settingsManager.minImageDimension = v; _minImageDimension.value = v
        reloadChapter()
    }

    fun setSortOrder(v: SortOrder) {
        settingsManager.sortOrder = v; _sortOrder.value = v
        reloadChapter()
    }

    fun setReadingMode(v: ReadingMode) {
        settingsManager.readingMode = v; _readingMode.value = v
    }

    fun setKeepScreenAwake(v: Boolean) {
        settingsManager.keepScreenAwake = v; _keepScreenAwake.value = v
    }

    fun setAutoMarkRead(v: Boolean) {
        settingsManager.autoMarkRead = v; _autoMarkRead.value = v
    }

    fun setPreloadNext(v: Boolean) {
        settingsManager.preloadNextChapter = v; _preloadNext.value = v
    }

    companion object {
        /**
         * Increment when extraction or sort logic changes so stale caches are
         * automatically discarded.
         *
         *   1 – initial
         *   2 – dimension filter added
         *   3 – HTML-order detection + QP decode (fixes reverse-order sites)
         */
        const val PARSER_VERSION = 3

        private val IMAGE_EXTS = setOf("jpg", "png", "webp", "gif", "bmp")
    }
}
