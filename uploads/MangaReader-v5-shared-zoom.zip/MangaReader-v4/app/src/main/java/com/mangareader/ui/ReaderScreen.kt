package com.mangareader.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.SubcomposeAsyncImage
import com.mangareader.data.Chapter
import com.mangareader.data.ReadingMode
import com.mangareader.data.ReadingProgress
import com.mangareader.manager.SettingsManager.SortOrder
import com.mangareader.viewmodel.ReaderViewModel
import java.io.File
import kotlin.math.roundToInt

private val BAR_BG = Color.Black.copy(alpha = 0.78f)

// ── Zoom constants ─────────────────────────────────────────────────────────────

/** Minimum allowed scale — the reader never shrinks below native size. */
private const val ZOOM_MIN = 1f

/** Maximum allowed scale. */
private const val ZOOM_MAX = 4f

/**
 * Treat scale values within this distance of [ZOOM_MIN] as "not zoomed".
 * Prevents floating-point residue from a pinch that nearly returns to 1×
 * from leaving the surface locked in pan-mode.
 */
private const val ZOOM_EPSILON = 0.01f

// ── ReaderScreen ───────────────────────────────────────────────────────────────

@Composable
fun ReaderScreen(
    viewModel: ReaderViewModel,
    chapter: Chapter,
    chapterIndex: Int,
    allChapters: List<Chapter>,
    initialProgress: ReadingProgress?,
    onBack: () -> Unit,
    onChapterChange: (Chapter, Int) -> Unit
) {
    BackHandler { onBack() }

    val pages       by viewModel.pages.collectAsStateWithLifecycle()
    val loading     by viewModel.loading.collectAsStateWithLifecycle()
    val error       by viewModel.error.collectAsStateWithLifecycle()
    val scrollSpeed by viewModel.scrollSpeed.collectAsStateWithLifecycle()
    val minDim      by viewModel.minImageDimension.collectAsStateWithLifecycle()
    val sortOrder   by viewModel.sortOrder.collectAsStateWithLifecycle()
    val readingMode by viewModel.readingMode.collectAsStateWithLifecycle()

    // Reset list position whenever the chapter changes.
    val listState = remember(chapter.id) { LazyListState() }

    var showControls by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }

    val savedChapterMatches = remember(initialProgress, chapter.id, chapterIndex) {
        initialProgress?.chapterId == chapter.id ||
            (initialProgress?.chapterId == null && initialProgress?.chapterIndex == chapterIndex)
    }

    LaunchedEffect(chapter.id) {
        viewModel.loadChapter(chapter, chapterIndex, allChapters)
    }

    // Restore scroll position once pages have loaded.
    var scrollRestored by remember(chapter.id) { mutableStateOf(false) }
    LaunchedEffect(pages.size) {
        if (pages.isNotEmpty() && !scrollRestored && savedChapterMatches) {
            scrollRestored = true
            val target = initialProgress!!.pageIndex.coerceIn(0, pages.size - 1)
            listState.scrollToItem(target, initialProgress.scrollOffset)
        } else if (pages.isNotEmpty()) {
            scrollRestored = true
        }
    }

    // Auto-save progress as the user scrolls.
    val firstVisible       = listState.firstVisibleItemIndex
    val firstVisibleOffset = listState.firstVisibleItemScrollOffset
    LaunchedEffect(firstVisible, firstVisibleOffset) {
        if (pages.isNotEmpty()) {
            viewModel.saveProgress(firstVisible, firstVisibleOffset)
            if (firstVisible >= pages.size - 1) viewModel.onLastPageReached()
        }
    }

    if (showSettings) {
        ReaderSettingsDialog(
            scrollSpeed   = scrollSpeed,
            minImageDim   = minDim,
            sortOrder     = sortOrder,
            readingMode   = readingMode,
            onScrollSpeed = { viewModel.setScrollSpeed(it) },
            onMinImageDim = { viewModel.setMinImageDimension(it) },
            onSortOrder   = { viewModel.setSortOrder(it) },
            onReadingMode = { viewModel.setReadingMode(it) },
            onReload      = { viewModel.reloadChapter(); showSettings = false },
            onDismiss     = { showSettings = false }
        )
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        when {
            loading      -> LoadingState()
            error != null -> ErrorState(
                message = error!!,
                onRetry = { viewModel.loadChapter(chapter, chapterIndex, allChapters) }
            )
            pages.isEmpty() -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                Text("No images found", color = Color.White.copy(alpha = 0.6f))
            }
            else -> {
                when (readingMode) {
                    ReadingMode.HORIZONTAL -> HorizontalReader(
                        pages        = pages,
                        chapterIndex = chapterIndex,
                        allChapters  = allChapters,
                        initialPage  = if (savedChapterMatches) initialProgress?.pageIndex ?: 0 else 0,
                        onTap        = { showControls = !showControls },
                        onProgress   = { page -> viewModel.saveProgress(page) },
                        onLastPage   = { viewModel.onLastPageReached() },
                        onPrev       = { val i = chapterIndex - 1; onChapterChange(allChapters[i], i) },
                        onNext       = { val i = chapterIndex + 1; onChapterChange(allChapters[i], i) }
                    )
                    else -> VerticalReader(
                        pages        = pages,
                        listState    = listState,
                        scrollSpeed  = scrollSpeed,
                        webtoonMode  = readingMode == ReadingMode.WEBTOON,
                        chapterIndex = chapterIndex,
                        allChapters  = allChapters,
                        onTap        = { showControls = !showControls },
                        onPrev       = { val i = chapterIndex - 1; onChapterChange(allChapters[i], i) },
                        onNext       = { val i = chapterIndex + 1; onChapterChange(allChapters[i], i) }
                    )
                }

                // Reading-progress bar along the top edge (vertical modes only).
                if (pages.isNotEmpty() && readingMode != ReadingMode.HORIZONTAL) {
                    val fraction = (firstVisible + 1).toFloat() / pages.size
                    LinearProgressIndicator(
                        progress   = { fraction.coerceIn(0f, 1f) },
                        modifier   = Modifier
                            .fillMaxWidth()
                            .height(2.dp)
                            .align(Alignment.TopCenter),
                        color      = MaterialTheme.colorScheme.primary,
                        trackColor = Color.White.copy(alpha = 0.1f)
                    )
                }

                // Top / bottom control overlay — toggled by tapping anywhere
                // on the reading surface (handled inside ReaderZoomSurface).
                AnimatedVisibility(
                    visible  = showControls,
                    enter    = fadeIn(),
                    exit     = fadeOut(),
                    modifier = Modifier.fillMaxSize()
                ) {
                    Box(Modifier.fillMaxSize()) {
                        ReaderTopBar(
                            chapter       = chapter,
                            chapterIndex  = chapterIndex,
                            totalChapters = allChapters.size,
                            currentPage   = firstVisible + 1,
                            totalPages    = pages.size,
                            onBack        = onBack,
                            onSettings    = { showSettings = true },
                            modifier      = Modifier.align(Alignment.TopCenter)
                        )
                        ReaderBottomBar(
                            chapterIndex  = chapterIndex,
                            totalChapters = allChapters.size,
                            onPrev        = { val i = chapterIndex - 1; onChapterChange(allChapters[i], i) },
                            onNext        = { val i = chapterIndex + 1; onChapterChange(allChapters[i], i) },
                            modifier      = Modifier.align(Alignment.BottomCenter)
                        )
                    }
                }
            }
        }
    }
}

// ── Shared zoom surface ────────────────────────────────────────────────────────

/**
 * Applies a SINGLE shared zoom-and-pan transform to its entire [content] subtree,
 * mirroring the behaviour of PDF viewers and Google Photos.
 *
 * **Gesture model**
 * - Two-finger pinch → zoom [ZOOM_MIN]–[ZOOM_MAX], anchored to the pinch centroid
 *   so the point under your fingers stays visually fixed.
 * - One-finger drag → pan, but ONLY when scale > 1×.  At exactly 1× all touches
 *   are never consumed here, so a [LazyColumn] or [HorizontalPager] inside
 *   [content] can scroll and swipe completely unobstructed.
 * - Single-tap → calls [onTap] immediately (no disambiguation delay).
 * - Double-tap → no zoom; calls [onTap] as well (shows / hides the reader UI).
 *
 * **Recomposition cost**
 * `scale`, `offsetX`, and `offsetY` are read exclusively inside a `graphicsLayer`
 * lambda, which runs in the drawing phase rather than the composition phase.
 * Changing these values on every gesture frame therefore causes ZERO recompositions —
 * only a graphics-layer redraw.  The separate [isZoomed] flag (threaded into
 * [content] so callers can set `userScrollEnabled = !isZoomed`) changes value at
 * most twice per zoom session (crossing the 1× threshold in each direction).
 *
 * **What is NOT transformed**
 * The `graphicsLayer` is applied only to the inner wrapper Box that holds
 * [content].  Overlay composables placed *outside* this surface (progress bars,
 * top/bottom bars) are unaffected by the zoom.
 */
@Composable
private fun ReaderZoomSurface(
    onTap: () -> Unit,
    content: @Composable (isZoomed: Boolean) -> Unit
) {
    // ── Transform state ───────────────────────────────────────────────────────
    // These are read only inside graphicsLayer { } → zero recompositions while
    // a gesture is in progress.  Writing from the pointerInput coroutine is safe
    // because MutableState<T> is snapshot-aware and thread-safe.
    var scale   by remember { mutableStateOf(1f) }
    var offsetX by remember { mutableStateOf(0f) }
    var offsetY by remember { mutableStateOf(0f) }

    // Boolean threshold flag.  Only flips value when scale crosses ZOOM_MIN,
    // so it causes at most two recompositions per zoom session.
    var isZoomed by remember { mutableStateOf(false) }

    // Container pixel size; populated by onSizeChanged before any gesture fires.
    var containerW by remember { mutableStateOf(0) }
    var containerH by remember { mutableStateOf(0) }

    // Stable wrapper so neither pointerInput block needs to restart on every
    // recomposition even though the outer lambda changes reference each time.
    val currentOnTap by rememberUpdatedState(onTap)

    Box(
        Modifier
            .fillMaxSize()
            .onSizeChanged { containerW = it.width; containerH = it.height }

            // ── Tap → toggle reader UI (no zoom on double-tap) ───────────────
            .pointerInput(Unit) {
                detectTapGestures(onTap = { currentOnTap() })
            }

            // ── Pinch-to-zoom + single-finger pan (when zoomed) ──────────────
            .pointerInput(Unit) {
                awaitEachGesture {
                    // requireUnconsumed = false: the tap detector (sibling block)
                    // may have already consumed the DOWN event.
                    awaitFirstDown(requireUnconsumed = false)

                    // Read scale directly from MutableState — always current value.
                    var active = scale > ZOOM_MIN + ZOOM_EPSILON

                    while (true) {
                        val event   = awaitPointerEvent()
                        val fingers = event.changes.count { it.pressed }

                        // A second finger arriving means a pinch has started;
                        // activate even if we were at 1× when the gesture began.
                        if (fingers >= 2) active = true

                        if (active) {
                            val zoomDelta = event.calculateZoom()
                            val panDelta  = event.calculatePan()

                            if (zoomDelta != 1f || panDelta != Offset.Zero) {
                                val centroid = event.calculateCentroid(useCurrent = false)
                                val newScale = (scale * zoomDelta).coerceIn(ZOOM_MIN, ZOOM_MAX)

                                // ── Anchored-zoom math ────────────────────────
                                // We want the pixel under the pinch centroid to
                                // stay visually fixed as scale changes.
                                //
                                // In local space (before graphicsLayer):
                                //   screen_pos = center + scale*(local - center) + offset
                                //
                                // Holding screen_pos constant while scale moves
                                // from old → new value, solving for the new offset:
                                //   new_offset = (centroid - center)
                                //              + panDelta
                                //              - (centroid - center - old_offset) * ratio
                                val cx    = containerW / 2f
                                val cy    = containerH / 2f
                                val ratio = newScale / scale
                                val relX  = centroid.x - cx - offsetX
                                val relY  = centroid.y - cy - offsetY
                                val rawX  = (centroid.x - cx) + panDelta.x - relX * ratio
                                val rawY  = (centroid.y - cy) + panDelta.y - relY * ratio

                                // ── Clamp ─────────────────────────────────────
                                // Limit translation so the surface never exposes
                                // empty black space at any edge.
                                val maxX = (containerW * (newScale - 1f) / 2f).coerceAtLeast(0f)
                                val maxY = (containerH * (newScale - 1f) / 2f).coerceAtLeast(0f)

                                scale   = newScale
                                offsetX = rawX.coerceIn(-maxX, maxX)
                                offsetY = rawY.coerceIn(-maxY, maxY)

                                // Update the boolean flag only when it changes
                                // (avoids unnecessary recompositions mid-gesture).
                                val zoomed = newScale > ZOOM_MIN + ZOOM_EPSILON
                                if (zoomed != isZoomed) isZoomed = zoomed
                            }

                            // Consume position changes so the enclosed
                            // LazyColumn / HorizontalPager never scrolls or
                            // swipes while a pan or pinch is in progress.
                            event.changes.forEach { if (it.positionChanged()) it.consume() }
                        }

                        if (event.changes.none { it.pressed }) break
                    }

                    // ── Snap-to-1× ────────────────────────────────────────────
                    // If the user pinched almost all the way back, remove any
                    // floating-point residue so the surface is exactly at rest.
                    if (scale <= ZOOM_MIN + ZOOM_EPSILON) {
                        scale    = ZOOM_MIN
                        offsetX  = 0f
                        offsetY  = 0f
                        isZoomed = false
                    }
                }
            }
    ) {
        // Apply the shared transform to reading content ONLY.
        // Sibling composables (overlays, progress bars) placed outside this
        // surface in the parent Box are not affected.
        Box(
            Modifier.graphicsLayer {
                scaleX       = scale
                scaleY       = scale
                translationX = offsetX
                translationY = offsetY
            }
        ) {
            content(isZoomed)
        }
    }
}

// ── Vertical / Webtoon reader ──────────────────────────────────────────────────

/**
 * Vertical continuous-scroll reader shared by [ReadingMode.VERTICAL] and
 * [ReadingMode.WEBTOON].  All pages are rendered as a single [LazyColumn];
 * the [ReaderZoomSurface] above applies one shared transform to the whole
 * column so zooming feels like a single long canvas.
 *
 * At 1× [LazyColumn] scrolls normally.
 * At >1× scrolling is suspended (`userScrollEnabled = false`) and a
 * single-finger drag pans the zoomed surface instead.
 */
@Composable
private fun VerticalReader(
    pages: List<File>,
    listState: LazyListState,
    scrollSpeed: Float,
    webtoonMode: Boolean,
    chapterIndex: Int,
    allChapters: List<Chapter>,
    onTap: () -> Unit,
    onPrev: () -> Unit,
    onNext: () -> Unit
) {
    ReaderZoomSurface(onTap = onTap) { isZoomed ->
        LazyColumn(
            state             = listState,
            flingBehavior     = rememberMomentumFlingBehavior(scrollSpeed),
            // Freeze the list while zoomed so single-finger drags pan the
            // shared surface instead of scrolling past pages.
            userScrollEnabled = !isZoomed,
            modifier          = Modifier.fillMaxSize()
        ) {
            itemsIndexed(pages, key = { _, f -> f.absolutePath }) { _, file ->
                MangaPage(
                    file     = file,
                    modifier = Modifier
                        .fillMaxWidth()
                        .wrapContentHeight()
                        // Webtoon mode: flush strip, no inter-page gap.
                        .then(if (webtoonMode) Modifier else Modifier.padding(bottom = 2.dp))
                )
            }
            item(key = "footer") {
                ChapterFooter(chapterIndex, allChapters.size, onPrev, onNext)
            }
        }
    }
}

// ── Horizontal (pager) reader ──────────────────────────────────────────────────

/**
 * One-page-at-a-time horizontal pager.  The [ReaderZoomSurface] wraps only the
 * [HorizontalPager]; overlay buttons and the progress bar are placed OUTSIDE the
 * surface so they remain unscaled at all zoom levels.
 *
 * At 1× the pager swipes normally.
 * At >1× swiping is suspended (`userScrollEnabled = false`) so single-finger
 * drags pan the zoomed page instead of advancing to the next one.
 */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun HorizontalReader(
    pages: List<File>,
    chapterIndex: Int,
    allChapters: List<Chapter>,
    initialPage: Int,
    onTap: () -> Unit,
    onProgress: (Int) -> Unit,
    onLastPage: () -> Unit,
    onPrev: () -> Unit,
    onNext: () -> Unit
) {
    val pagerState = rememberPagerState(
        initialPage = initialPage.coerceIn(0, pages.size - 1),
        pageCount   = { pages.size }
    )

    LaunchedEffect(pagerState.currentPage) {
        onProgress(pagerState.currentPage)
        if (pagerState.currentPage >= pages.size - 1) onLastPage()
    }

    Box(Modifier.fillMaxSize()) {
        // Zoom surface wraps only the pager.  Overlays below are siblings, not
        // children, so they are never scaled by the shared transform.
        ReaderZoomSurface(onTap = onTap) { isZoomed ->
            HorizontalPager(
                state             = pagerState,
                userScrollEnabled = !isZoomed,
                modifier          = Modifier.fillMaxSize()
            ) { page ->
                MangaPage(
                    file     = pages[page],
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        // ── Unscaled overlays ─────────────────────────────────────────────────

        if (pagerState.currentPage >= pages.size - 1 && allChapters.size > chapterIndex + 1) {
            Box(Modifier.align(Alignment.BottomCenter).padding(24.dp)) {
                Button(onClick = onNext) {
                    Icon(Icons.Default.NavigateNext, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Next Chapter")
                }
            }
        }

        Row(
            Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 60.dp),
            horizontalArrangement = Arrangement.Center
        ) {
            val fraction = (pagerState.currentPage + 1).toFloat() / pages.size
            LinearProgressIndicator(
                progress   = { fraction },
                modifier   = Modifier.fillMaxWidth(0.6f).height(2.dp),
                color      = MaterialTheme.colorScheme.primary,
                trackColor = Color.White.copy(alpha = 0.2f)
            )
        }
    }
}

// ── Manga page (stateless — zoom is owned by ReaderZoomSurface) ───────────────

/**
 * Renders a single page image.
 *
 * There is NO zoom state here.  All scaling is handled by the [ReaderZoomSurface]
 * that wraps the entire reading container; this composable is intentionally
 * simple and stateless.
 */
@Composable
private fun MangaPage(file: File, modifier: Modifier) {
    SubcomposeAsyncImage(
        model              = file,
        contentDescription = null,
        contentScale       = ContentScale.FillWidth,
        modifier           = modifier,
        loading = {
            Box(
                Modifier
                    .fillMaxWidth()
                    .aspectRatio(0.7f),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(
                    color       = Color.White.copy(alpha = 0.5f),
                    modifier    = Modifier.size(32.dp),
                    strokeWidth = 2.dp
                )
            }
        },
        error = {
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(80.dp)
                    .background(Color(0xFF1A1A1A)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "Page failed to load",
                    color = Color.White.copy(alpha = 0.4f),
                    style = MaterialTheme.typography.labelSmall
                )
            }
        }
    )
}

// ── Settings dialog ────────────────────────────────────────────────────────────

@Composable
private fun ReaderSettingsDialog(
    scrollSpeed: Float,
    minImageDim: Int,
    sortOrder: SortOrder,
    readingMode: ReadingMode,
    onScrollSpeed: (Float) -> Unit,
    onMinImageDim: (Int) -> Unit,
    onSortOrder: (SortOrder) -> Unit,
    onReadingMode: (ReadingMode) -> Unit,
    onReload: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest  = onDismiss,
        containerColor    = Color(0xFF1C1340),
        titleContentColor = Color.White,
        title = { Text("Reader Settings", style = MaterialTheme.typography.titleMedium) },
        text  = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                // ── Reading mode ──────────────────────────────────────────────
                SettingLabel("Reading Mode")
                Column(Modifier.selectableGroup()) {
                    ReadingMode.entries.forEach { mode ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .selectable(
                                    selected = readingMode == mode,
                                    role     = Role.RadioButton,
                                    onClick  = { onReadingMode(mode) }
                                )
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = readingMode == mode,
                                onClick  = null,
                                colors   = RadioButtonDefaults.colors(
                                    selectedColor   = MaterialTheme.colorScheme.primary,
                                    unselectedColor = Color.White.copy(alpha = 0.4f)
                                )
                            )
                            Spacer(Modifier.width(8.dp))
                            Column {
                                Text(
                                    mode.label(),
                                    color = Color.White,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Text(
                                    mode.hint(),
                                    color = Color.White.copy(alpha = 0.42f),
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }
                    }
                }

                Spacer(Modifier.height(8.dp))

                // ── Scroll speed ──────────────────────────────────────────────
                SettingRow("Scroll Speed", "%.1fx".format(scrollSpeed))
                Slider(
                    value         = scrollSpeed,
                    onValueChange = onScrollSpeed,
                    valueRange    = 0.8f..3.0f,
                    steps         = 10,
                    colors        = sliderColors()
                )
                SettingHint("How far pages travel after a flick. 1.0× = stock.")

                Spacer(Modifier.height(8.dp))

                // ── Image filter ──────────────────────────────────────────────
                SettingRow(
                    "Image Filter",
                    if (minImageDim == 0) "Off" else "${minImageDim}px min"
                )
                Slider(
                    value         = minImageDim.toFloat(),
                    onValueChange = { onMinImageDim(it.roundToInt()) },
                    valueRange    = 0f..800f,
                    steps         = 7,
                    colors        = sliderColors()
                )
                SettingHint(
                    "Hides images smaller than this (site icons, banners). " +
                    "Recommended: 200–400px. Takes effect after reload."
                )

                Spacer(Modifier.height(8.dp))

                // ── Page order ────────────────────────────────────────────────
                SettingLabel("Page Order")
                Column(Modifier.selectableGroup()) {
                    data class Opt(val o: SortOrder, val label: String, val hint: String)
                    listOf(
                        Opt(SortOrder.AUTO,      "Auto",       "Detect from HTML structure (recommended)."),
                        Opt(SortOrder.ENCOUNTER, "File Order", "Use MHTML encounter order."),
                        Opt(SortOrder.URL_PAGE,  "URL Number", "Sort by number in image URL.")
                    ).forEach { opt ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .selectable(
                                    selected = sortOrder == opt.o,
                                    role     = Role.RadioButton,
                                    onClick  = { onSortOrder(opt.o) }
                                )
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            RadioButton(
                                selected = sortOrder == opt.o,
                                onClick  = null,
                                colors   = RadioButtonDefaults.colors(
                                    selectedColor   = MaterialTheme.colorScheme.primary,
                                    unselectedColor = Color.White.copy(alpha = 0.4f)
                                )
                            )
                            Spacer(Modifier.width(8.dp))
                            Column {
                                Text(
                                    opt.label,
                                    color = Color.White,
                                    style = MaterialTheme.typography.bodyMedium
                                )
                                Text(
                                    opt.hint,
                                    color = Color.White.copy(alpha = 0.42f),
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick  = onReload,
                    modifier = Modifier.fillMaxWidth(),
                    colors   = ButtonDefaults.outlinedButtonColors(
                        contentColor = MaterialTheme.colorScheme.primary
                    )
                ) {
                    Icon(Icons.Default.Refresh, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Reload chapter from file")
                }
                TextButton(
                    onClick  = onDismiss,
                    modifier = Modifier.align(Alignment.End),
                    colors   = ButtonDefaults.textButtonColors(
                        contentColor = MaterialTheme.colorScheme.primary
                    )
                ) { Text("Done") }
            }
        }
    )
}

// ── Shared helpers ─────────────────────────────────────────────────────────────

@Composable private fun SettingLabel(text: String) {
    Text(text, color = Color.White, style = MaterialTheme.typography.titleSmall)
}

@Composable private fun SettingRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
        Text(label, color = Color.White, style = MaterialTheme.typography.titleSmall)
        Text(
            value,
            color = MaterialTheme.colorScheme.primary,
            style = MaterialTheme.typography.titleSmall
        )
    }
}

@Composable private fun SettingHint(text: String) =
    Text(
        text,
        style = MaterialTheme.typography.labelSmall,
        color = Color.White.copy(alpha = 0.42f)
    )

@Composable private fun sliderColors() = SliderDefaults.colors(
    thumbColor       = MaterialTheme.colorScheme.primary,
    activeTrackColor = MaterialTheme.colorScheme.primary
)

private fun ReadingMode.label() = when (this) {
    ReadingMode.VERTICAL   -> "Vertical"
    ReadingMode.WEBTOON    -> "Webtoon (no gaps)"
    ReadingMode.HORIZONTAL -> "Horizontal (pager)"
}

private fun ReadingMode.hint() = when (this) {
    ReadingMode.VERTICAL   -> "Standard manga pages with small gaps."
    ReadingMode.WEBTOON    -> "Continuous strip, no gaps between pages."
    ReadingMode.HORIZONTAL -> "One page at a time, swipe left/right."
}

// ── Top / Bottom bars ──────────────────────────────────────────────────────────

@Composable
private fun ReaderTopBar(
    chapter: Chapter,
    chapterIndex: Int,
    totalChapters: Int,
    currentPage: Int,
    totalPages: Int,
    onBack: () -> Unit,
    onSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier        = modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 10.dp),
        shape           = RoundedCornerShape(18.dp),
        color           = BAR_BG,
        shadowElevation = 6.dp
    ) {
        Row(
            modifier          = Modifier.padding(horizontal = 6.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, "Back", tint = Color.White)
            }
            Column(Modifier.weight(1f)) {
                Text(
                    chapter.title,
                    color    = Color.White,
                    style    = MaterialTheme.typography.titleSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    "Ch ${chapterIndex + 1}/$totalChapters  ·  Pg $currentPage/$totalPages",
                    color = Color.White.copy(alpha = 0.6f),
                    style = MaterialTheme.typography.labelSmall
                )
            }
            IconButton(onClick = onSettings) {
                Icon(Icons.Default.Settings, "Settings", tint = Color.White)
            }
        }
    }
}

@Composable
private fun ReaderBottomBar(
    chapterIndex: Int,
    totalChapters: Int,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier        = modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 10.dp),
        shape           = RoundedCornerShape(18.dp),
        color           = BAR_BG,
        shadowElevation = 6.dp
    ) {
        Row(
            modifier              = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment     = Alignment.CenterVertically
        ) {
            TextButton(
                onClick = onPrev,
                enabled = chapterIndex > 0,
                colors  = ButtonDefaults.textButtonColors(contentColor = Color.White)
            ) {
                Icon(Icons.Default.NavigateBefore, null)
                Spacer(Modifier.width(4.dp))
                Text("Prev")
            }
            Text(
                "Ch ${chapterIndex + 1} / $totalChapters",
                color = Color.White.copy(alpha = 0.7f),
                style = MaterialTheme.typography.labelMedium
            )
            TextButton(
                onClick = onNext,
                enabled = chapterIndex < totalChapters - 1,
                colors  = ButtonDefaults.textButtonColors(contentColor = Color.White)
            ) {
                Text("Next")
                Spacer(Modifier.width(4.dp))
                Icon(Icons.Default.NavigateNext, null)
            }
        }
    }
}

@Composable
private fun ChapterFooter(
    chapterIndex: Int,
    totalChapters: Int,
    onPrev: () -> Unit,
    onNext: () -> Unit
) {
    Column(
        Modifier
            .fillMaxWidth()
            .background(Color(0xFF111111))
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        HorizontalDivider(color = Color.White.copy(alpha = 0.1f))
        Spacer(Modifier.height(20.dp))
        if (chapterIndex < totalChapters - 1) {
            Button(
                onClick  = onNext,
                modifier = Modifier.fillMaxWidth(0.7f),
                colors   = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary
                )
            ) {
                Icon(Icons.Default.NavigateNext, null)
                Spacer(Modifier.width(6.dp))
                Text("Next Chapter")
            }
        } else {
            Text(
                "You've reached the end!",
                color = Color.White.copy(alpha = 0.5f),
                style = MaterialTheme.typography.bodyMedium
            )
        }
        if (chapterIndex > 0) {
            Spacer(Modifier.height(12.dp))
            TextButton(
                onClick = onPrev,
                colors  = ButtonDefaults.textButtonColors(
                    contentColor = Color.White.copy(alpha = 0.6f)
                )
            ) {
                Icon(Icons.Default.NavigateBefore, null, Modifier.size(18.dp))
                Spacer(Modifier.width(4.dp))
                Text("Previous Chapter")
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

// ── Loading / error states ─────────────────────────────────────────────────────

@Composable
private fun LoadingState() {
    Box(Modifier.fillMaxSize(), Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator(color = Color.White)
            Spacer(Modifier.height(16.dp))
            Text(
                "Extracting chapter…",
                color = Color.White.copy(alpha = 0.7f),
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@Composable
private fun ErrorState(message: String, onRetry: () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            Icons.Default.BrokenImage, null,
            Modifier.size(56.dp),
            tint = Color.Red.copy(alpha = 0.7f)
        )
        Spacer(Modifier.height(16.dp))
        Text(message, color = Color.White, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(20.dp))
        Button(onClick = onRetry) { Text("Retry") }
    }
}
