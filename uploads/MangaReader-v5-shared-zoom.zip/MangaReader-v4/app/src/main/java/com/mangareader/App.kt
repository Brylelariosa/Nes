package com.mangareader

import android.app.Application
import android.graphics.Bitmap
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.disk.DiskCache
import coil.memory.MemoryCache

/**
 * Configures the app-wide Coil [ImageLoader].
 *
 * MEMORY CACHE
 * Coil's default memory cache is 25 % of the app's available memory. We
 * keep that cap but request RGB_565 bitmaps (2 bytes/pixel instead of 4),
 * so in practice we cache roughly twice as many decoded pages for the same
 * memory budget — important on mid-range devices where a full-res manga page
 * can be 1–2 MB when decoded.
 *
 * DISK CACHE
 * Coil stores network-fetched images in its own disk cache; this app loads
 * from local files (SAF URIs and absolute paths), so the Coil disk cache is
 * not used for manga pages. However thumbnails *are* loaded via Coil from
 * file paths, so we give it a small sane limit (50 MB) to avoid unbounded
 * growth if Coil decides to cache the JPEG data.
 *
 * CROSSFADE
 * A short crossfade smooths thumbnail loads in the library grid without
 * being distracting.
 */
class App : Application(), ImageLoaderFactory {

    override fun newImageLoader(): ImageLoader =
        ImageLoader.Builder(this)
            .bitmapConfig(Bitmap.Config.RGB_565)
            .memoryCache {
                MemoryCache.Builder(this)
                    .maxSizePercent(0.25)   // up to 25 % of available memory
                    .build()
            }
            .diskCache {
                DiskCache.Builder()
                    .directory(cacheDir.resolve("coil_cache"))
                    .maxSizeBytes(50L * 1024 * 1024)   // 50 MB ceiling
                    .build()
            }
            .crossfade(durationMillis = 180)
            .build()
}
