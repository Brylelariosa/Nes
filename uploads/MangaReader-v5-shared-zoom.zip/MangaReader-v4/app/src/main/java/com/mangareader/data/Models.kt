package com.mangareader.data

import java.util.UUID

// ── Core domain models ─────────────────────────────────────────────────────────

data class Chapter(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val number: Float,
    val mhtmlPath: String,   // content:// URI (SAF) or absolute file path
    val seriesId: String
)

data class Series(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val sourceFolderUri: String? = null,
    val sourceZipUri: String? = null,
    val chapters: List<Chapter> = emptyList(),
    val addedAt: Long = System.currentTimeMillis()
)

/**
 * Tracks where the user left off in a series.
 *
 * [chapterId] is the stable identifier used for restoration; it survives
 * chapters being added, removed, or reordered. [chapterIndex] is kept for
 * display convenience and as a legacy fallback when [chapterId] is null
 * (data from builds before this field was added).
 *
 * [lastReadAt] enables "recently read" sorting without a separate table.
 */
data class ReadingProgress(
    val seriesId: String,
    val chapterIndex: Int = 0,
    val chapterId: String? = null,   // preferred stable reference
    val pageIndex: Int = 0,
    val scrollOffset: Int = 0,
    val lastReadAt: Long = System.currentTimeMillis()
)

// ── UI preference enums (stored as Int in SettingsManager) ────────────────────

/** How chapters are sorted in the library grid. */
enum class LibrarySortOrder {
    RECENTLY_ADDED,   // default — newest import first
    LAST_READ,        // series you touched most recently first
    TITLE_AZ,         // alphabetical A→Z
    TITLE_ZA,         // alphabetical Z→A
    CHAPTER_COUNT     // most chapters first
}

/**
 * How pages are laid out in the reader.
 *
 * VERTICAL / WEBTOON both use a vertical LazyColumn; WEBTOON removes the
 * small gap between pages so long-strip comics read as one continuous strip.
 * HORIZONTAL uses a HorizontalPager (one page at a time, swipe left/right).
 */
enum class ReadingMode {
    VERTICAL,    // standard manga: pages stacked, slight gap
    WEBTOON,     // long-strip: pages flush with no gap
    HORIZONTAL   // one page at a time, swipe to advance
}
