# ── Gson ─────────────────────────────────────────────────────────────────────
# Gson reads/writes our model classes via reflection on their field names
# (no @SerializedName annotations are used). Without these rules, R8 would
# rename/remove fields on Chapter/Series/ReadingProgress and existing users'
# saved library + reading-progress JSON would silently fail to deserialize
# after updating (no crash — Gson just returns nulls/defaults), effectively
# resetting their library and reading history. Keep the whole model package
# exactly as written so the JSON shape never changes.
-keep class com.mangareader.data.** { *; }

# Generic type information (e.g. TypeToken<List<Series>>) is stored as
# attributes Proguard/R8 strips by default — Gson needs it to deserialize
# generic collections correctly.
-keepattributes Signature
-keepattributes *Annotation*

-dontwarn sun.misc.**
-keep class com.google.gson.stream.** { *; }
-keep class com.google.gson.reflect.TypeToken { *; }
-keep class * extends com.google.gson.reflect.TypeToken

# ── ViewModel ────────────────────────────────────────────────────────────────
# androidx.lifecycle's default ViewModelProvider.Factory constructs
# LibraryViewModel/ReaderViewModel via reflection on their constructor.
# AndroidX's own consumer rules normally cover this already, but this is kept
# explicitly as a backstop so it can never silently regress.
-keep public class * extends androidx.lifecycle.ViewModel {
    public <init>(...);
}

# ── Debuggability ────────────────────────────────────────────────────────────
# Keep enough info that e.printStackTrace() output (used throughout the
# parser/manager classes) still shows real file/line info instead of "Unknown
# Source" after obfuscation.
-keepattributes SourceFile,LineNumberTable
